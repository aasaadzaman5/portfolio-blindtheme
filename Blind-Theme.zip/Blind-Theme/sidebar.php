		
<div class="sidebar">

	<div class="category-widget widget">
		<?php dynamic_sidebar('sidbar2'); ?>
	</div>


	<div class="flickr-widget widget">
		<?php dynamic_sidebar('footerwidget3'); ?>
	</div>

	<div class="tags-widget widget">
	<?php dynamic_sidebar('sidbar'); ?>
		
	</div>

</div>