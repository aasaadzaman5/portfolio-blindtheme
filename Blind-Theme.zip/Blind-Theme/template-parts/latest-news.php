<?php 
	
	
	function blind_latest_news( $latestnews1, $latestnews2 ){
		
		$bllatestnews = shortcode_atts(array(
			'latest_news_title'	=>	'Latest News',
		), $latestnews1 );
		
		ob_start();
			
		?>
		
		<section class="news-section">
			<div class="container">
				<div class="title-section alt-title">
					<h1><?php echo $bllatestnews ['latest_news_title']; ?></h1>
				</div>
				<div class="news-box">
					<div class="arrow-box">
						<a href="#" class="prev"><i class="fa fa-angle-left"></i></a>
						<a href="#" class="next"><i class="fa fa-angle-right"></i></a>
					</div>
					
					<div id="owl-demo" class="owl-carousel">
						
						<?php 
							$lnews = new WP_Query(array(
										'post_type'				=>	'latnewss',
										'post_per_page'			=>	1000
									));
						while($lnews-> have_posts()) : $lnews-> the_post(); ?>
					
						<div class="item news-post">
							<?php the_post_thumbnail(); ?>
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<ul class="post-tags">
								<li><?php the_time('d F, Y'); ?></li>
								<li><a href="<?php the_permalink(); ?>"><?php the_category(); ?></a> </li>
								<li><a href="<?php the_permalink(); ?>"><?php the_tags(); ?></a></li>
							</ul>
							<p><?php echo wp_trim_words(get_the_content(), 30, true ); ?></p>
							<a href="<?php the_permalink(); ?>">Read More</a>
						</div>
						
						<?php  endwhile; ?>
						
						
					</div>
				</div>

			</div>
		</section>
	
		
	<?php 
		
		return ob_get_clean();
		
	}
	add_shortcode('blindnews','blind_latest_news');











?>