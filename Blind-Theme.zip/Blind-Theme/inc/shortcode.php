<?php

	



	
	
	function blind_latest_news( $latestnews1, $latestnews2 ){
		
		$bllatestnews = shortcode_atts(array(
			'latest_news_title'	=>	'Latest News',
			
			
		), $latestnews1 );
		
		ob_start();
			
		?>
		
		<section class="news-section">
			<div class="container">
				<div class="title-section alt-title">
					<h1><?php echo $bllatestnews ['latest_news_title']; ?></h1>
				</div>
				<div class="news-box">
					<div class="arrow-box">
						<a href="#" class="prev"><i class="fa fa-angle-left"></i></a>
						<a href="#" class="next"><i class="fa fa-angle-right"></i></a>
					</div>
					
					<div id="owl-demo" class="owl-carousel">
					
					<?php 
						$lnews = new WP_Query(array(
									'post_type'				=>	'latnewss',
									'posts_per_page'			=>	1000
								));
					while($lnews-> have_posts()) : $lnews-> the_post(); ?>
					
						<div class="item news-post">
							<?php the_post_thumbnail(); ?>
							<h2><a href="#"><?php the_title(); ?></a></h2>
							<ul class="post-tags">
								<li><?php the_time('d F, Y'); ?></li>
								<li><a href="#"><?php the_author(); ?></a> </li>
								<li><a href="#"><?php the_tags(); ?></a></li>
							</ul>
							<p><?php the_content(); ?></p>
						</div>
						
						<?php  endwhile; ?>
						
						
					</div>
				</div>

			</div>
		</section>
	
		
	<?php 
		
		return ob_get_clean();
		
	}
	add_shortcode('blindnews','blind_latest_news');
	
	
	// HERE YOU CAN FIND ALL ABOUT OUR SERVICES Shortcode
	function blind_serv($ser1, $ser2){
	ob_start();
		$serv_me = shortcode_atts(array(
			'serv_title'		=>	'HERE YOU CAN FIND ALL ABOUT OUR SERVICES',
			'serv_sub_title'	=>	'Best Services'
		 ),$ser1);
		
		
			
		?>
		
		<section class="services-offer-section">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="default-article">
							<h1><?php echo $serv_me['serv_title'];  ?></h1>
							<span><?php echo $serv_me['serv_sub_title'];  ?></span>
							<p><?php echo $ser2;  ?></p>
							
						</div>
					</div>
					<div class="col-md-9">
						<div class="services-box-mas iso-call">
						
						
							<?php 
								
								$ser = new WP_Query(array(
									'post_type'				=>	'service',
									'posts_per_page'			=>	5
								));
							
							while($ser->have_posts()) : $ser->the_post(); ?>
						
								<div class="services-project">
									<div class="services-gal">
										<?php the_post_thumbnail(); ?>
										<div class="hover-services">
											<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
											<span><?php the_tags(); ?></span>
										</div>
									</div>
								</div>
							
							<?php endwhile; ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		
	<?php 
	
		return ob_get_clean();
		
	}
	add_shortcode('blindserv','blind_serv');
	
	// ************************************
	
	
// Our Latest Projects Shortcode
	
	function blind_our_latest_project($lat1, $lat2){
		
		$blatest_project = shortcode_atts(array(
			'blatest_title'			=>	'Rana',
			'blatest_sub_title'		=>	'Rana will be survive'
		),$lat1);
		
		ob_start();
			
	?>
		
		<section class="projects-section">
			<div class="container">
				<div class="title-section">
					<h1><?php echo $blatest_project['blatest_title']; ?></h1>
					<span><?php echo $blatest_project['blatest_sub_title']; ?></span>
					<p><?php echo $lat2; ?></p>
				</div>
			</div>
			
			
			<div class="project-box iso-call">
			
			
				<?php 
					$b_project_post = new WP_Query(array(
						'post_type'			=>		'bprojects',
						'posts_per_page'		=>		6
					));
				while($b_project_post-> have_posts()) : $b_project_post-> the_post(); ?>
			
					<div class="project-post">
						<?php the_post_thumbnail(); ?>
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<span><?php the_tags(); ?></span>
							</div>
						</div>
					</div>
					
				<?php endwhile; ?>
				
			</div>
		</section>
	<?php 
		
		return ob_get_clean();
		
	}
	add_shortcode('blind_latest','blind_our_latest_project');
	
	// ************************************
	
	
	// Blind About Us Shortcode
	
	function blind_about( $about1, $about2 ){
		
		$blind_about_us = shortcode_atts(array(
			'about_title'		=>	'Here you can know everythink about us',
			'about_subtitle'	=>	'About us',
		), $about1 );
		
		ob_start();
	?>
		<section class="about-section">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="default-article">
							<h1><?php echo $blind_about_us['about_title']; ?></h1>
							<span><?php echo $blind_about_us['about_subtitle']; ?></span>
							<p><?php echo $about2; ?></p>
						</div>
					</div>
				</div>
			</div>
		</section>
		
	<?php 
		return ob_get_clean();
	}
	add_shortcode('blind_about','blind_about');
	
	// ************************************
	
	
	// Testimonila Section For Shortcode
	
	function blind_testimonial( $testimonial1, $testimonial2 ){
		
		$blind_testi = shortcode_atts(array(
			'testimonial_title1'		=>	'Rana 1',
			'testimonial_jobtitle1'		=>	'Software Engeneer',
			'testimonial_paragraph1'	=>	'Paragraph 1',
			'testimonial_title2'		=>	'Rana 2',
			'testimonial_jobtitle2'		=>	'Software Engeneer',
			'testimonial_paragraph2'	=>	'Paragraph 2',
			'testimonial_title3'		=>	'Rana 3',
			'testimonial_jobtitle3'		=>	'Software Engeneer',
			'testimonial_paragraph3'	=>	'Paragraph 3',
			
			
		), $testimonial1 );
		
		ob_start();
	?>
		<section class="testimonial-section">
			<div class="container">

				<div class="testimonial-box">
					<ul class="bxslider">
						<li>
							<h2><?php echo $blind_testi['testimonial_title1']; ?></h2>
							<span><?php echo $blind_testi['testimonial_jobtitle1']; ?></span>
							<p><?php echo $blind_testi['testimonial_paragraph1']; ?></p>
						</li>
						<li>
							<h2><?php echo $blind_testi['testimonial_title2']; ?></h2>
							<span><?php echo $blind_testi['testimonial_jobtitle2']; ?></span>
							<p><?php echo $blind_testi['testimonial_paragraph2']; ?></p>
						</li>
						<li>
							<h2><?php echo $blind_testi['testimonial_title3']; ?></h2>
							<span><?php echo $blind_testi['testimonial_jobtitle3']; ?></span>
							<p><?php echo $blind_testi['testimonial_paragraph3']; ?></p>
						</li>
					</ul>
				</div>

			</div>
		</section>
		
	<?php 
		return ob_get_clean();
	}
	add_shortcode('blind_testimonial','blind_testimonial');
	
	// ************************************
	
	
	// Contact Us Section For Shortcode
	
	function blind_contact(){
		ob_start();
	?>
		
	<?php 
		return ob_get_clean();
	}
	add_shortcode('blind_contact','blind_contact');
	
	// ************************************
	
	
	// Client Shortcode
	function blind_client( $clients1, $clients2 ){
		
		
		$blind_clients = shortcode_atts(array(
			'clients_title1'		=>	'Here are our Customer list',
			'clients_subtitle1'		=>	'Our Clients',
			
			

			
		), $clients1 );
		
		ob_start();
	?>
		<section class="clients-section">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<ul class="client-list">
						
						
						<?php 
						$clients = new WP_Query(array(
									'post_type'				=>	'ourclients',
									'posts_per_page'			=>	-1
								));
							while($clients-> have_posts()) : $clients-> the_post(); ?>
						
							<li>
								<a href="<?php echo get_post_meta(get_the_id(), 'linkid' , true); ?>" target="_blank" ><?php the_post_thumbnail(); ?></a>
							</li>
							
							<?php endwhile; ?>
						
							
						</ul>
					</div>
					<div class="col-md-3">
						<div class="default-article left-align">
							<h1><?php echo $blind_clients['clients_title1']; ?></h1>
							<span><?php echo $blind_clients['clients_subtitle1']; ?></span>
							<p><?php echo $clients2; ?></p>
							
						</div>
					</div>
				</div>

			</div>
		</section>
		
	<?php 
		return ob_get_clean();
	}
	add_shortcode('blind_client','blind_client');
	
	// ************************************
	
	// Blind About Us Section
	
	function blind_about_us($bltabs1, $bltabs2 ){
		
			
			$bltabs = shortcode_atts(array(
				'options_title1'				=>	'Option 1',
				'options_title1_paragraph'		=>	'Paragraph 1',
				'options_title2'				=>	'Option 2',
				'options_title2_paragraph'		=>	'Paragraph 2',
				'options_title3'				=>	'Option 3',
				'options_title3_paragraph'		=>	'Paragraph 3',
				
				'accordion_title1'				=>	'Accordion 1',
				'accordion_title1_paragraph'	=>	'paragraph 1',
				'accordion_title2'				=>	'Accordion 2',
				'accordion_title2_paragraph'	=>	'paragraph 2',
				'accordion_title3'				=>	'Accordion 3',
				'accordion_title3_paragraph'	=>	'paragraph 3',
				'accordion_title4'				=>	'Accordion 4',
				'accordion_title4_paragraph'	=>	'paragraph 4',
				
				'btabs_last_title'				=>	'Who are you',
			
			
			),$bltabs1 );
			
		
		ob_start();
		?>
		<section class="about-alternative-section">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<!-- Nav tabs -->
						<div class="tab-posts-box">
							<ul class="nav nav-tabs" id="myTab">
								<li class="active">
									<a href="#option1" data-toggle="tab"><?php echo $bltabs['options_title1']; ?></a>
								</li>
								<li>
									<a href="#option2" data-toggle="tab"><?php echo $bltabs['options_title2']; ?></a>
								</li>
								<li>
									<a href="#option3" data-toggle="tab"><?php echo $bltabs['options_title3']; ?></a>
								</li>
							</ul>

							<div class="tab-content">
								<div class="tab-pane active" id="option1">
									<img src="<?php echo get_template_directory_uri(); ?>/upload/others/1.jpg" alt="">

									<p><?php echo $bltabs['options_title1_paragraph']; ?></p>
								</div>
								<div class="tab-pane" id="option2">
									<img src="<?php echo get_template_directory_uri(); ?>/upload/others/2.jpg" alt="">

									<p><?php echo $bltabs['options_title2_paragraph']; ?></p>
								</div>
								<div class="tab-pane" id="option3">
									<img src="<?php echo get_template_directory_uri(); ?>/upload/others/3.jpg" alt="">

									<p><?php echo $bltabs['options_title3_paragraph']; ?></p>

								</div>
							</div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="accordion-box">
							<div class="accord-elem active">
								<div class="accord-title">
									<a class="accord-link" href="#"></a>
									<h2><?php echo $bltabs['accordion_title1']; ?></h2>
								</div>
								<div class="accord-content">
									<p><?php echo $bltabs['accordion_title1_paragraph']; ?></p>
								</div>
							</div>

							<div class="accord-elem">
								<div class="accord-title">
									<a class="accord-link" href="#"></a>
									<h2><?php echo $bltabs['accordion_title2']; ?></h2>
								</div>
								<div class="accord-content">
									<p><?php echo $bltabs['accordion_title2_paragraph']; ?></p>
								</div>
							</div>

							<div class="accord-elem">
								<div class="accord-title">
									<a class="accord-link" href="#"></a>
									<h2><?php echo $bltabs['accordion_title3']; ?></h2>
								</div>
								<div class="accord-content">
									<p><?php echo $bltabs['accordion_title3_paragraph']; ?></p>
								</div>
							</div>

							<div class="accord-elem">
								<div class="accord-title">
									<a class="accord-link" href="#"></a>
									<h2><?php echo $bltabs['accordion_title4']; ?></h2>
								</div>
								<div class="accord-content">
									<p><?php echo $bltabs['accordion_title4_paragraph']; ?></p>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-4">
						<div class="second-article">
							<img src="<?php echo get_template_directory_uri(); ?>/upload/others/3a.jpg" alt="">
							<h2><?php echo $bltabs['btabs_last_title']; ?></h2>
							<p><?php echo $bltabs2; ?></p>
						</div>
					</div>

				</div>
			</div>
		</section>
	<?php
		return ob_get_clean();
	}
	add_shortcode('blind_tabs_accor','blind_about_us');
	
	// ************************************
	
	
	// Blind Project Section Shortcode Start..
	function blind_projects(){
		ob_start();
	?>
		
		<section class="projects-section projects-page-section">
			<div class="container">
				<div class="title-section alt-title">
					<div class="row">
						<div class="col-md-5">
							<h1>Latest Project</h1>
						</div>
						<div class="col-md-7">
							<ul class="filter">
								<li><a class="active" href="#" data-filter="*">Show All</a></li>
								<li><a href="#" data-filter=".buildings">Buildings</a></li>
								<li><a href="#" data-filter=".interior">Interior</a></li>
								<li><a href="#" data-filter=".energy">Energy</a></li>
								<li><a href="#" data-filter=".isolation">Isolation</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="project-box iso-call col3">
					<div class="project-post buildings isolation">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/1.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Elegant Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/1.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post interior default-size">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/3.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Beatiful House</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/3.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post interior isolation">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/5.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Afarist Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/5.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post energy isolation">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/7.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">traditional Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/7.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post interior buildings">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/8.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">traditional Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/8.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post energy isolation buildings">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/10.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">traditional Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/10.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post buildings isolation">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/2.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Elegant Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/2.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post interior">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/4.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Beatiful House</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/4.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
					<div class="project-post interior isolation">
						<img src="<?php echo get_template_directory_uri(); ?>/upload/projects/6.jpg" alt="">
						<div class="hover-box">
							<div class="inner-hover">
								<h2><a href="single-project.html">Afarist Building</a></h2>
								<span>bulding, house</span>
								<a href="single-project.html" class="link"><i class="fa fa-link"></i></a>
								<a href="<?php echo get_template_directory_uri(); ?>/upload/projects/6.jpg" class="zoom"><i class="fa fa-arrows-alt"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		
	<?php 
		return ob_get_clean();
	}
	add_shortcode('blind_projt','blind_projects');
	
	// ************************************
	
	// Header Banner Shortcode
	
		 function banner_short( $pagebanner1, $pagebanner2 ){
			$banner_page = shortcode_atts(array(
				'banner_title'	=>	'',
				'banner_title2'	=>	'',
				'banner_title3'	=>	'',
				'banner_title2_link'	=>	'',
				'banner_title3_link'	=>	'',
			), $pagebanner1 );
			 ob_start();
			?>
				<section class="page-banner-section">
					<div class="container">
						<h2><?php echo $banner_page['banner_title']; ?></h2>
						<ul class="page-depth">
							<li><a href="<?php echo $banner_page['banner_title2_link']; ?>"><?php echo $banner_page['banner_title2']; ?></a></li>
							<li><a href="<?php echo $banner_page['banner_title3_link']; ?>"><?php echo $banner_page['banner_title3']; ?></a></li>
						</ul>
					</div>
				</section> 
		 <?php
			 return ob_get_clean();
		 }
		add_shortcode('page_banner','banner_short');
	
	//*****************
	
	
	
	// Shortcode End here
	
	
	
	
	
	if(function_exists (vc_map)){
		
	
	vc_map(array(
		'name'		=>	'Page Banner',
		'base'		=>	'page_banner',
		'params'	=>	array(
			array(
				'param_name'	=>	'banner_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Banner Title',
			),
			array(
				'param_name'	=>	'banner_title2',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Banner Title2',
			),
			array(
				'param_name'	=>	'banner_title3',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Banner Title3',
			),
			array(
				'param_name'	=>	'banner_title2_link',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Banner Title2 Link',
			),
			array(
				'param_name'	=>	'banner_title3_link',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Banner Title3 Link',
			),
		)
	));
	
	vc_map(array(
		'name'		=>	'Blind Latest News',
		'base'		=>	'blindnews',
		'params'	=>	array(
			array(
				'param_name'	=>	'latest_news_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here Blind Latest News Title',
			),
		)
	));
	
	
	vc_map(array(
		'name'		=>	'Blind About Us & Accordion',
		'base'		=>	'blind_tabs_accor',
		'title'		=>	'Add Your Content',
		'params'	=>	array(
			array(
				'param_name'	=>	'options_title1',
				'type'			=>	'textfield',
				'heading'		=>	'Option Title 2',
			),
			array(
				'param_name'	=>	'options_title1_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Option Paragraph 1',
			),
			array(
				'param_name'	=>	'options_title2',
				'type'			=>	'textfield',
				'heading'		=>	'Option Title 2',
			),
				array(
				'param_name'	=>	'options_title2_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Option Paragraph 2',
			),
			array(
				'param_name'	=>	'options_title3',
				'type'			=>	'textfield',
				'heading'		=>	'Option Title 3',
			),
			array(
				'param_name'	=>	'options_title3_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Option Paragraph 3',
			),
			// Accordion
			array(
				'param_name'	=>	'accordion_title1',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion 1',
			),
			array(
				'param_name'	=>	'accordion_title1_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion Paragraph 1',
			),
			array(
				'param_name'	=>	'accordion_title2',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion 2',
			),
			array(
				'param_name'	=>	'accordion_title2_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion Paragraph 2',
			),
			
			array(
				'param_name'	=>	'accordion_title3',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion 3',
			),
			array(
				'param_name'	=>	'accordion_title3_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion Paragraph 3',
			),
			array(
				'param_name'	=>	'accordion_title4',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion 4',
			),
			array(
				'param_name'	=>	'accordion_title4_paragraph',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion Paragraph 4',
			),
			// Artical
			array(
				'param_name'	=>	'btabs_last_title',
				'type'			=>	'textfield',
				'heading'		=>	'Accordion Paragraph 4',
			),
			array(
				'param_name'	=>	'content',
				'type'			=>	'textarea_html',
				'heading'		=>	'Accordion Paragraph 4',
			),
			
			
		)
		
	));	
	
	
	vc_map(array(
		'name'		=>	'Blind Services',
		'base'		=>	'blindserv',
		'params'	=>	array(
			array(
				'param_name'	=>	'serv_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Services Heading'
			),
			 array(
				'param_name'	=>	'serv_sub_title',
				 'type'			=>	'textfield',
				 'heading'		=>	'Add your Sub Title Here'
			 ),
			 array(
				 'param_name'	=>	'content',
				 'type'			=>	'textarea_html',
				 'heading'		=>	'Add your content here'
			  )
		 )
	));
	vc_map(array(
		'name'		=>	'Blind Latest Project',
		'base'		=>	'blind_latest',
		'params'	=>	array(
			array(
				'param_name'	=>	'blatest_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Your Latest Project Title Here'
			),
			array(
				'param_name'	=>	'blatest_sub_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Your Latest Project Sub Title Here'
			),
			array(
				'param_name'	=>	'content',
				'type'			=>	'textarea_html',
				'heading'		=>	'Add Latest Project Short Description'
			)
		)
	));
	vc_map(array(
		'name'		=>	'Blind About Us',
		'base'		=>	'blind_about',
		'params'		=>	array(
			array(
				'param_name'	=>	'about_title',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here About Heading',
			),
			array(
				'param_name'	=>	'about_subtitle',
				'type'			=>	'textfield',
				'heading'		=>	'Add Here About Sub Heading',
			),
			array(
				'param_name'	=>	'content',
				'type'			=>	'textarea_html',
				'heading'		=>	'Add About Heading Details',
			),
		),
	));
	vc_map(array(
		'name'		=>	'Blind Testimonial',
		'base'		=>	'blind_testimonial',
		'params'	=>	array(
		// First
			array(
				'param_name'	=>	'testimonial_title1',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Title 1',
			),
				array(
				'param_name'	=>	'testimonial_jobtitle1',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Job Title 1',
			),
				array(
				'param_name'	=>	'testimonial_paragraph1',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Text 1',
			),
			// Second
				array(
				'param_name'	=>	'testimonial_title2',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Title 2',
			),
				array(
				'param_name'	=>	'testimonial_jobtitle2',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Job Title 2',
			),	array(
				'param_name'	=>	'testimonial_paragraph2',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Text 2',
			),
			// Third
				array(
				'param_name'	=>	'testimonial_title3',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Title 3',
			),
				array(
				'param_name'	=>	'testimonial_jobtitle3',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Job Title 3',
			),
				array(
				'param_name'	=>	'testimonial_paragraph3',
				'type'			=>	'textfield',
				'heading'		=>	'Testimonial Text 3',
			),
			
			
		)
	));
	vc_map(array(
		'name'		=>	'Blind Contact',
		'base'		=>	'blind_contact'
	));
	vc_map(array(
		'name'		=>	'Blind Client',
		'base'		=>	'blind_client',
		'params'	=>	array(
		
			array(
				'param_name'	=> 	'clients_title1',
				'type'			=> 	'textfield',
				'heading'		=> 	'Client Title',
			),
			array(
				'param_name'	=> 	'clients_subtitle1',
				'type'			=> 	'textfield',
				'heading'		=> 	'Client Sub-Title',
			),
			array(
				'param_name'	=> 	'content',
				'type'			=> 	'textarea_html',
				'heading'		=> 	'Client Paragraph',
			),
		)
	));
	vc_map(array(
		'name'	=>	'Blind Project Page',
		'base'	=>	'blind_projt'
	));
	
	

}
		
			
	
	
	




















 ?>