<?php global $blind_theme; ?>

<!doctype html>


<html <?php language_attributes(); ?> class="no-js">
<head>
	

	<meta charset="<?php bloginfo('charset'); ?>">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Roboto:400,400italic,500,500italic,700,900,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Dancing+Script:400,700' rel='stylesheet' type='text/css'>
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	
	<script src='https://www.google.com/recaptcha/api.js'></script>
	<script>
document.addEventListener( 'wpcf7mailsent', function( event ) {
    location = 'http://localhost/soft-tech/sample-page/';
}, false );
</script>
	
	
	<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>

	<!-- Container -->
	<div id="container">
		<!-- Header
		    ================================================== -->
		<header class="clearfix">
			<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
				<div class="top-line">
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<p>
									<span><i class="fa fa-phone"></i><?php echo $blind_theme['htop']; ?></span>
									<span><i class="fa fa-envelope-o"></i><?php echo $blind_theme['hemail']; ?></span>
									<a href=" # "><i class="fa fa-user"></i><?php echo $blind_theme['login']; ?></a>
								</p>
							</div>	
							<div class="col-md-6">
								<ul class="social-icons">
									<li><a class="facebook" href="<?php echo $blind_theme['fb']; ?>"><i class="fa fa-facebook"></i></a></li>
									<li><a class="twitter" href="<?php echo $blind_theme['tw']; ?>"><i class="fa fa-twitter"></i></a></li>
									<li><a class="rss" href="<?php echo $blind_theme['rss']; ?>"><i class="fa fa-rss"></i></a></li>
									<li><a class="google" href="<?php echo $blind_theme['go']; ?>"><i class="fa fa-google-plus"></i></a></li>
									<li><a class="linkedin" href="<?php echo $blind_theme['lk']; ?>"><i class="fa fa-linkedin"></i></a></li>
									<li><a class="pinterest" href="<?php echo $blind_theme['pn']; ?>"><i class="fa fa-pinterest"></i></a></li>
								</ul>
							</div>	
						</div>
					</div>
				</div>
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="<?php echo esc_url(home_url( '/')); ?>"><img src="<?php echo $blind_theme['logouplo']['url']; ?>" alt=""></a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						
						<?php wp_nav_menu(array(
							'theme_location'	=>		'main-menu',
							'menu_class'		=>		'nav navbar-nav navbar-right',
							'walker'			=>		new blind_Menu()
							
							
							
						)); ?>
					
						
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container -->
			</nav>
			
		</header>
		<!-- End Header -->