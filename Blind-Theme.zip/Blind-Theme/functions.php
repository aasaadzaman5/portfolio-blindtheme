<?php 

	function blind_theme_basic(){
		
		add_theme_support('title-tag');
		add_theme_support('post-thumbnails');
		add_theme_support('custom-header');
		add_theme_support('custom-background');
		add_theme_support('woocommerce');
		add_theme_support('post-formats',array('audio','gallery','video','quote'));
		
		load_theme_textdomain('blind', get_template_directory() . '/languages');
		
		
		register_nav_menus(array(
			'main-menu'	=>	'Main Menu'
		));
		register_post_type('service',array(
			'public'	=>	true,
			
			'labels'			=>	array(
				'name'			=>	__('Blind Services', 'blind' ),
				'add_new'		=>	__('Add New Service', 'blind' ),
				'all_items'		=>	__('All Services', 'blind' ),
				'add_new_item'	=>	__('Add New Service', 'blind' ),
			),
			'supports'			=>	array('title','editor','thumbnail'),
			'menu_icon'			=>	'dashicons-format-status',
		));
		register_post_type('bprojects',array(
			'public'			=>		true,
			'labels'			=>		array(
				'name'				=>	__('Blind Latest Project','blind' ),
				'add_new'			=>	__('Add Latest Project','blind' ),
				'all_items'			=>	__('All Project','blind' ),
				'add_new_item'		=>	__('Add New Project','blind' ),
			),
			'supports'			=>	array('title','editor','thumbnail'),
			'menu_icon'			=>	'dashicons-images-alt',
		));
		register_post_type('blindabouttt',array(
			'public'			=>		true,
			'labels'			=>		array(
				'name'				=>	__('Blind About Us','blind' ),
				'add_new'			=>	__('Add About Us','blind' ),
				'all_items'			=>	__('All About Us','blind' ),
				'add_new_item'		=>	__('Add New About','blind' ),
			),
			'supports'			=>	array('title','editor','thumbnail'),
			'menu_icon'			=>	'dashicons-media-document',
		));
		register_post_type('latnewss',array(
			'public'			=>		true,
			'labels'			=>		array(
				'name'				=>	__('Blind Latest News','blind' ),
				'add_new'			=>	__('Add News','blind' ),
				'all_items'			=>	__('All News','blind' ),
				'add_new_item'		=>	__('Add New News','blind' ),
			),
			'supports'			=>	array('title','editor','thumbnail','tags'),
			'menu_icon'			=>	'dashicons-format-aside',
		));
		register_taxonomy('blindtaxonomycat','latnewss',array(
			'public'		=>	true,
			'hierarchical'	=>	true,
			'labels'		=>	array(
				'name'			=>	__('Latest News Category','blind'),
			)
		));
		register_taxonomy('blindtaxonomytags','latnewss',array(
			'public'		=>	true,
			'hierarchical'	=>	true,
			'labels'		=>	array(
				'name'			=>	__('Latest News Tags','blind'),
			)
		));
		
		// Custom Post Type for Our Clients
		register_post_type( 'ourclients' , array(
			'public'			=>	true,
			'supports'			=>	array( 'title','thumbnail' ),
			'menu_icon'			=>	'dashicons-visibility',
			'labels'			=>		array(
				'name'				=>	__('Blind Clients','blind' ),
				'add_new'			=>	__('Add Clients','blind' ),
				'all_items'			=>	__('All Clients','blind' ),
				'add_new_item'		=>	__('Add New Clients','blind' ),
			),
		));
		
	}
	add_action('after_setup_theme','blind_theme_basic');

		// Widgets
	
	function blind_widgets_field(){
		

	
		// Widgets Field Register
	
	register_sidebar(array(
		'name' 				=>	'Footer Widget1',
		'id' 				=>	'footerwidget',
		'description' 		=>	__('Add Your About','blind' ),
		'class'        		=> '',
		'before_widget' 	=>	'<div class="footer-widget">',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"


	));
	register_sidebar(array(
		'name' 				=>	'Footer Widget2',
		'id' 				=>	'footerwidget2',
		'description' 		=>	__('Add Your Tags/Catagories','blind' ),
		'class'         	=> '',
		'before_widget' 	=>	'<div class="footer-widget">',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"
	));
	register_sidebar(array(
		'name' 				=>	'Footer Widget3',
		'id' 				=>	'footerwidget3',
		'description' 		=>	__('Add any Image at anywhere','blind' ),
		'class'         	=> '',
		'before_widget' 	=>	'<div class="footer-widget">',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"
	));
	register_sidebar(array(
		'name' 				=>	'Footer Widget4',
		'id' 				=>	'footerwidget4',
		'description' 		=>	__('Add Your Address','blind' ),
		'class'         	=> '',
		'before_widget' 	=>	'<div class="footer-widget">',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"
	));
	// For Sidebar
	register_sidebar(array(
		'name' 				=>	'Sidebar 1',
		'id' 				=>	'sidbar',
		'description' 		=>	__('Add Tags, Flicker Image','blind' ),
		'class'         	=> '',
		'before_widget' 	=>	'<div class="tags-widget"> ',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"
	));
	
	register_sidebar(array(
		'name' 				=>	'Sidebar 2',
		'id' 				=>	'sidbar2',
		'description' 		=>	__('Add Catagories, Archives','blind' ),
		'class'         	=> '',
		'before_widget' 	=>	'<div class="category-widget category-list"> ',
		'after_widget' 		=>	"</div>\n",
		'before_title' 		=>	'<h2>',
		'after_title' 		=>	"</h2>\n"
	));
	
	register_widget('Blind_Flicker_Widget');	
	register_widget('Blind_Working_Hourr');	
	
		
	}
	add_action('widgets_init','blind_widgets_field');
	

	// Admin Panel Custom  Scripts
	
	function blind_admin_links(){

		wp_enqueue_media();
		
		// If I register script then I can deregister it agian. 
		
		wp_register_script('admin_custom_script',get_theme_file_uri().'/js/logo.upload.js',array('jquery'),'',true); // Here also I can use get_template_directory_uri().
		wp_enqueue_script('admin_custom_script');
		
		wp_register_script('flicker_custom_script', get_template_directory_uri().'/js/flicker.widget.js', array('jquery'), '', true );
		wp_enqueue_script('flicker_custom_script');

	}
	add_action('admin_enqueue_scripts','blind_admin_links');


	class Blind_Flicker_Widget extends WP_Widget{
		public function __construct(){
			parent::__construct('flicker_widget','Custom Image Widget Item',array(
				'description'	=>	'Add Your Flicker Widget'
			));
		}
		
		public function widget($args, $instance){
			?>
				<?php echo $args['before_widget']; ?>
					<?php echo $args['before_title']; ?><?php echo $instance['title']; ?><?php echo $args['after_title']; ?>
					<ul class="flickr">
						<li><a href="<?php the_permalink(); ?>"><img src="<?php echo $instance['flicker_image']; ?>" alt="<?php echo $instance['flicker_image']; ?>"></a></li>
						
					</ul>
				<?php echo $args['after_widget']; ?>
			<?php
		}
		
		public function form( $instance ){
			?>
				<div class="bflicker_widget_title">
					<p>
						<label for="<?php echo $this->get_field_id('title'); ?>">Image Title</label>
						<input type="text"  name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo $instance['title']; ?>" class="widefat" />
					</p>
				</div>
				
				<div class="bflicker_widget_title">
					<p>
						<button for="" id="flicker-imager-id" class="button-primary">Upload Image</button>
					</p>
					<p>
						<input type="hidden" name="<?php echo $this->get_field_name('flicker_image'); ?>" value="<?php echo $instance['flicker_image']; ?>"  class="flicker-imagee" />
					</p>
				</div>
				<div class="flicker-show-image">
					<img src="<?php echo $instance['flicker_image']; ?>" height="auto" width="300px"/>
				</div>
				
				
				
			<?php
		}
			
	
		
	}

	// Working Hour Widget Start

	class Blind_Working_Hourr extends WP_Widget{
			public function __construct(){
				parent::__construct('working_hours','Working Hours',array(
					'description'	=>	__('Add Your Working Hour','blind' ),
				));
			}
			
		// widget Method Use for What will be show on Front End
		// update Method Use for What will be happen after Submitt
		// form Method Use for What will be looke like widget form
		// __construct Method Use for add widget to Available Widgets area..
		
		public function widget($args, $instance){?>
			
			<?php echo $args ['before_widget']; ?>

			<div class="info-widget">

					<?php echo $args ['before_title']; ?><?php echo $instance['title']; ?><?php echo $args ['after_title']; ?>
					<div id="first-par">
						<p class="first-par"><?php echo $instance['description']; ?></p>
					</div>
					<div id="footer_tele">
						<p><span><?php echo $instance['telephone_title']; ?></span> <?php echo $instance['telephone']; ?></p>
					</div>
					<div id="footer_ema">
						<p><span><?php echo $instance['email_title']; ?></span> <?php echo $instance['email']; ?></p>
					</div>
					<div id="footer_web">
						<a href="http://mdasaduzzamanrana.com/" target="_blank"><p><span><?php echo $instance['website_title']; ?></span> <?php echo $instance['website']; ?> </p></a>
					</div>
					<div id="footer_time">
						<p><span><?php echo $instance['time_title']; ?></span> <?php echo $instance['time']; ?></p>
					</div>
					<div id="footer_img">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $instance['blind_working_hour_image']; ?>" alt="<?php echo $intacne['title']; ?>" /></a>
					</div>
			</div>

			<?php echo $args ['after_widget']; ?>

		<?php }



		public function form($instance){
			?>
			
			<div class="working_hour_title">
				<p>
					<label for="<?php echo $this->get_field_id('title'); ?>">Title</label>
					<input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" class="widefat"/>
				</p>
			</div>

			<div class="working_hour_description">
				<p>
					<label for="<?php echo $this->get_field_id('description'); ?>">Description</label>
					<textarea id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" class="widefat"><?php echo $instance['description']; ?></textarea>
				</p>
			</div>
			
			<div class="working_hour_telephone_title">
				<p>
					<label for="<?php echo $this->get_field_id('telephone_title'); ?>">Telephone Title</label>
					<input type="text" id="<?php echo $this->get_field_id('telephone_title'); ?>" class="widefat" name="<?php echo $this->get_field_name('telephone_title'); ?>" value="<?php echo $instance['telephone_title']; ?>">
				</p>
			</div>
			
			<div class="working_hour_telephone">
				<p>
					<label for="<?php echo $this->get_field_id('telephone'); ?>">Telephone</label>
					<input type="text" id="<?php echo $this->get_field_id('telephone'); ?>" class="widefat" name="<?php echo $this->get_field_name('telephone'); ?>" value="<?php echo $instance['telephone']; ?>">
				</p>
			</div>
			
			<div class="working_hour_email_title">
				<p>
					<label for="<?php echo $this->get_field_id('email_title'); ?>">Email Title</label>
					<input type="text" class="widefat" id="<?php echo $this->get_field_id('email_title'); ?>" name="<?php echo $this->get_field_name('email_title'); ?>" value="<?php echo $instance['email_title']; ?>">
				</p>
			</div>
			
			<div class="working_hour_email">
				<p>
					<label for="<?php echo $this->get_field_id('email'); ?>">Email</label>
					<input type="text" class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" value="<?php echo $instance['email']; ?>">
				</p>
			</div>
			
			<div class="working_hour_website_title">
				<p>
					<label for="<?php echo $this->get_field_id('website_title'); ?>">Website Title</label>
					<input type="text" class="widefat" id="<?php echo $this->get_field_id('website_title'); ?>" name="<?php echo $this->get_field_name('website_title'); ?>" value="<?php echo $instance['website_title']; ?>">
				</p>
			</div>
			
			<div class="working_hour_website">
				<p>
					<label for="<?php echo $this->get_field_id('website'); ?>">Website</label>
					<input type="text" class="widefat" id="<?php echo $this->get_field_id('website'); ?>" name="<?php echo $this->get_field_name('website'); ?>" value="<?php echo $instance['website']; ?>">
				</p>
			</div>
			
			<div class="working_hour_working_hour_title">
				<p>
					<label for="<?php echo $this->get_field_id('time_title'); ?>">Wroking Time Title</label>
					<input type="text" id="<?php echo $this->get_field_id('time_title'); ?>" class="widefat" name="<?php echo $this->get_field_name('time_title');  ?>" value="<?php echo $instance['time_title']; ?>">
				</p>
			</div>

			<div class="working_hour_working_hour">
				<p>
					<label for="<?php echo $this->get_field_id('time'); ?>">Wroking Time</label>
					<input type="text" id="<?php echo $this->get_field_id('time'); ?>" class="widefat" name="<?php echo $this->get_field_name('time');  ?>" value="<?php echo $instance['time']; ?>">
				</p>
			</div>
			
			<div class="working_hour_image">
				<button class='button-primary' id="working_houre_er_link">Upload Logo</button>
				<p><input type="hidden" name="<?php echo $this->get_field_name('blind_working_hour_image'); ?>" value="<?php echo $instance['blind_working_hour_image']; ?>" class="working_hour_image_er_link widefat"/></p>

				<div class="image_show">
					<img src="<?php echo $instance['blind_working_hour_image']; ?>"/>
				</div>
			</div>

		<?php
		}

	}

	
	function blind_theme_links(){
		
		wp_enqueue_style('animate', get_template_directory_uri().'/css/animate.css');
		wp_enqueue_style('theme', get_template_directory_uri().'/css/owl.theme.css');
		wp_enqueue_style('carousel', get_template_directory_uri().'/css/owl.carousel.css');
		wp_enqueue_style('magnific', get_template_directory_uri().'/css/magnific-popup.css');
		wp_enqueue_style('bxslider', get_template_directory_uri().'/css/jquery.bxslider.css');
		wp_enqueue_style('bootstrap', get_template_directory_uri().'/css/bootstrap.min.css');
		wp_enqueue_style('awesome', get_template_directory_uri().'/css/font-awesome.css');
		wp_enqueue_style('flexslider', get_template_directory_uri().'/css/flexslider.css');
		wp_enqueue_style('style', get_template_directory_uri().'/css/style.css');
		wp_enqueue_style('style2', get_stylesheet_uri());
		
		
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery', get_template_directory_uri().'/js/jquery.min.js',array('jquery'),'',true);
		wp_enqueue_script('migrate', get_template_directory_uri().'/js/jquery.migrate.js',array('jquery'),'',true);
		wp_enqueue_script('bootstrap', get_template_directory_uri().'/js/bootstrap.min.js',array('jquery'),'',true);
		wp_enqueue_script('imagesloaded', get_template_directory_uri().'/js/jquery.imagesloaded.min.js',array('jquery'),'',true);
		wp_enqueue_script('flexslider', get_template_directory_uri().'/js/jquery.flexslider.js',array('jquery'),'',true);
		wp_enqueue_script('retina', get_template_directory_uri().'/js/retina-1.1.0.min.js',array('jquery'),'',true);
		wp_enqueue_script('plugins', get_template_directory_uri().'/js/plugins-scroll.js',array('jquery'),'',true);
		wp_enqueue_script('bxslider', get_template_directory_uri().'/js/jquery.bxslider.min.js',array('jquery'),'',true);
		wp_enqueue_script('magnific', get_template_directory_uri().'/js/jquery.magnific-popup.min.js',array('jquery'),'',true);
		wp_enqueue_script('carousel', get_template_directory_uri().'/js/owl.carousel.min.js',array('jquery'),'',true);
		wp_enqueue_script('isotope', get_template_directory_uri().'/js/jquery.isotope.min.js',array('jquery'),'',true);
		wp_enqueue_script('scroll', get_template_directory_uri().'/js/plugins-scroll.js',array('jquery'),'',true);
		wp_enqueue_script('script', get_template_directory_uri().'/js/script.js',array('jquery'),'',true);
		wp_enqueue_script('service', get_template_directory_uri().'/js/service.js',array('jquery'),'',true);
		
		
	}
	add_action('wp_enqueue_scripts','blind_theme_links');
	
	
	
	// file link
	
	require_once('cmb2/init.php');
	require_once('cmb2/custom.php');
	require_once('blind-walker-menu.php');
	require_once('tgm/rana.php');
	require_once('inc/shortcode.php');
	require_once('library/ReduxCore/framework.php');
	require_once('library/sample/rana.php');
	
	
	
	
	

	
	function blind_reply($avat){?>
		
		<ul class="comment-tree">
			<li>
				<div class="comment-box">
					<?php echo get_avatar($avat); ?>
					<div class="comment-content">
						<h4><?php echo get_comment_author(); ?> <a href="#">Reply</a></h4>
						<span><?php comment_date('d F, Y'); ?>. <?php comment_time('g:i a'); ?>.</span>
						<p><?php comment_text(); ?></p>
					</div>
				</div>
			</li>
		</ul>
		
	<?php }
	
	
	
	function dash(){
			if(get_post_type() == 'post') :
		?>
		
		<script type="text/javascript">
			
			jQuery(document).ready(function(){
				
				var blind_formatttt = jQuery('input[class="post-format"]:checked').attr('id');
					
					if(blind_formatttt == 'post-format-gallery'){
						jQuery('#gallery-img').show();
					}
					else{
						jQuery('#gallery-img').hide();
					}
					
					if(blind_formatttt == 'post-format-video'){
						jQuery('#video_box').show();
					}
					else{
						jQuery('#video_box').hide();
					}
				
				jQuery('input[class="post-format"]').change(function(){
					
					var blind_formatttt = jQuery('input[class="post-format"]:checked').attr('id');
					
					if(blind_formatttt == 'post-format-gallery'){
						jQuery('#gallery-img').show();
					}
					else{
						jQuery('#gallery-img').hide();
					}
					
					if(blind_formatttt == 'post-format-video'){
						jQuery('#video_box').show();
					}
					else{
						jQuery('#video_box').hide();
					}
					
					
				});
				
			});
			
			
		</script>
		
		
		
	<?php 
		endif;
	}
	add_action('admin_print_scripts','dash',1000);
	

?>