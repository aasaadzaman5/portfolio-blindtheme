<?php 

	wp_list_comments(array(
		'callback'		=>	'blind_reply'
	));
	
	comment_form();










?>