		
		<?php get_header(); 
			
			/*
				Template Name:	 Pagination Page
			*/
			
		?>
		<!-- 
		
		// This file  Just Created for learn pagination 
		// Its no need to keep on this file

		-->
		<!-- page-banner-section 
			================================================== -->
		<section class="page-banner-section">
			<div class="container">
				<h2>Blog</h2>
				<ul class="page-depth">
					<li><a href="index.html">Koncept</a></li>
					<li><a href="blog.html">Blog Fullwidth</a></li>
				</ul>
			</div>
		</section>
		<!-- End page-banner section -->

		<!-- blog section 
			================================================== -->
		<section class="blog-section">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="blog-box">
						
							<?php if(have_posts()): ?>
							
							<?php 
								$pag = get_query_var('paged');
								$blind_paginationnn = new WP_Query(array(
									'post_type'			=>	'service',
									'posts_per_page'	=>	2,
									'paged'				=>	$pag
								));
								
							while($blind_paginationnn-> have_posts()) : $blind_paginationnn-> the_post(); ?>

								<h1><?php the_title(); ?></h1>
								
							
							<?php endwhile; ?>
							
							<?php else : ?>
								<h2>You Didn't post yet...</h2>
							<?php endif; ?>
							
							
							<!-- Asrful Video No. 65 te details dawa ache -->
							
							<ul class="pagination-list">
								<?php echo paginate_links(array(
									'total'		=>	$blind_paginationnn-> max_num_pages,
									'current'	=>	$pag,
									'show_all'	=>	true,
									'type'		=>	'list'
								)); ?>
							</ul>
							

							<!--
							<ul class="pagination-list">
								<li><a href="#" class="prev-pag">prev</a></li>
								<li><a href="#" class="active">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#" class="next-pag">next</a></li>
							</ul>
							-->

						</div>
						
					</div>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- End blog section -->

		<?php get_footer(); ?>
		