	<?php get_header(); ?>

		<!-- page-banner-section 
			================================================== -->
		<section class="page-banner-section">
			<div class="container">
			
				<?php while(have_posts()) : the_post(); ?>
			
				<h2><?php the_title(); ?></h2>
				
				<?php endwhile; ?>
				
				<ul class="page-depth">
					<li><a href="<?php bloginfo('home'); ?>">Home</a></li>
					
					<?php while(have_posts()) : the_post(); ?>
					
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					
					<?php endwhile; ?>
					
				</ul>
			</div>
		</section>
		<!-- End page-banner section -->

		<!-- blog section 
			================================================== -->
		<section class="blog-section">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="blog-box">
						
							<?php 
								
							while( have_posts()) : the_post(); ?>
							
							<div class="blog-post single-post">
								<div class="post-content-text">
									<h1><?php the_title(); ?></h1>
									
									
									<ul class="post-tags">
										<li><?php the_time('d F, Y'); ?></li>
										<li><a href="#"><?php the_author(); ?></a> ,</li>
										<li><a href="#"><?php the_category(); ?></a></li>
									</ul>
									<?php get_template_part('/template-parts/content', get_post_format()); ?>
									<p><?php the_content(); ?></p>
								</div>
							</div>
							
							<?php endwhile; ?>
							
							<div class="comment-section">
								<h2><?php comments_popup_link('no comment','1 comment','% comments');?></h2>
								<?php comments_template(); ?>
							</div>
						</div>
						
					</div>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- End blog section -->

		<?php get_footer(); ?>