(function($){
	$(document).ready(function(){
		$('button#flicker-imager-id').live( "click" ,function(e){
			e.preventDefault();
			
			var flickerUploader = wp.media({
				'title'  :	'Upload Flicker Image',
				'button' :	{
					'text'	: 'Set Flicker Image'
				},
				'multiple'	: true
			});
			
			flickerUploader.open();
			
			flickerUploader.on("select", function(){
				var image = flickerUploader.state().get("selection").first().toJSON();
				
				var link = image.url;
				
				$("input.flicker-imagee").val( link );
				$('.flicker-show-image img').attr('src', link);
				
			});
			
		});
	});
})(jQuery)