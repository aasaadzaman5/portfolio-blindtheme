

(function($){
	
	$(document).ready(function (){
		
		$('.services-project:nth-child(1)').addClass('default-size');
		$('.services-project:nth-child(2)').addClass('snd-size');
		$('.project-post:nth-child(1)').addClass('buildings isolation');
		$('.project-post:nth-child(2)').addClass('buildings isolation snd-size');
		$('.project-post:nth-child(3)').addClass('interior default-size');
		$('.project-post:nth-child(4)').addClass('buildings');
		$('.project-post:nth-child(5)').addClass('interior isolation');
		$('.project-post:nth-child(6)').addClass('energy snd-size');
		
	});
	
})(jQuery)

