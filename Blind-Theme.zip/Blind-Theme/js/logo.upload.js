(function($){
	$(document).ready(function(){
		$('button#working_houre_er_link').live("click", function( e ){
			e.preventDefault();		 // I can also use - return false; -
			
			var imageUploader = wp.media({
					'title'	: 'Upload Your Working Hour Image',
					'button'	: {
						'text'	: 'Set The Image'
					},
					'multiple'	: false		// Set to true to allow multiple files to be selected
			});
			
			imageUploader.open();

			imageUploader.on("select", function(){
				var image = imageUploader.state().get("selection").first().toJSON();
				var link = image.url;

				$("input.working_hour_image_er_link").val( link );
				$('.image_show img').attr('src', link );

			});
			
		});	
	});
})(jQuery)