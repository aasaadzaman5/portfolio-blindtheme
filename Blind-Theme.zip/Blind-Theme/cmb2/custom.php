<?php 

	function amar_cmb2(){
		
		$mozammel = new_cmb2_box(array(
			'title'			=>		'Gllery Image',
			'id'			=>		'gallery-img',
			'object_types'	=>		array('post')
		));
		
		$mozammel -> add_field(array(
			'name'			=>	'Add Gllery Image',
			'id'			=>	'add-gallery-img',
			'type'			=>	'file_list'
		));
		
		
		// I can use same variabl($mozammel) or another variable for defferent meta box.
		$mozammel = new_cmb2_box(array(
			'title'			=>	'Video Box',
			'id'			=>	'video_box',
			'object_types'	=>	array('post' , 'blindabouttt')
		));
		
		$mozammel -> add_field(array(
			'name'			=>	'Add Your Video',
			'id'			=>	'add-video',
			'description'	=>	'Put a video link here',
			'type'			=>	'oembed'
		));
		
		// For Slider Box 
		$rvu = new_cmb2_box(array(
			'title'			=>	'Revulotion Slider Box',
			'id'			=>	'rev_sss',
			'object_types'	=>	array('page')
			
		));
		$rvu-> add_field(array(
			'name'			=>	'Put Slider Alias',
			'id'			=>	'rvealias',
			'type'			=>	'text'
		));
		
		// For About Us Section
		
		// $mozammel = new_cmb2_box(array(
			// 'title'			=>	'About Us Video',
			// 'id'			=>	'about-me',
			// 'object_types'	=>	array('blindabouttt')
		// ));
		// $mozammel -> add_field(array(
			// 'name'			=>	'Add Your Video',
			// 'id'			=>	'about-me-video',
			// 'description'	=>	'Put a video link here',
			// 'type'			=>	'oembed'
		// ));
		$mozammel = new_cmb2_box(array(
			'title'			=>	'About Us Image',
			'id'			=>	'about-img',
			'object_types'	=>	array('blindabouttt')
		));
		$mozammel-> add_field(array(
			'name'			=>	'Put Image Here',
			'id'			=>	'about-img-add',
			'type' => 'file_list',
		));
		
		$client = new_cmb2_box(array(
			'title'	=>	'Link',
			'id'	=>	'clientid',
			'object_types'	=>	array('ourclients')
		));
		
		$client-> add_field(array(
			'name'	=>	'Link of Your Post',
			'id'	=>	'linkid',
			'type'	=>	'text_url',
		));
		
		
		
		
	}
	add_action('cmb2_init','amar_cmb2');
















?>