		
		<?php
		
		/*
			Template Name: Home Page
		*/
		
		get_header(); ?>
			
			<?php if(get_post_meta(get_the_id(), 'rvealias', true)) : ?>
			<?php if(get_post_meta(get_the_id(), 'rvealias', true)) : ?>
				
				<?php while(have_posts()) : the_post(); ?>
					<?php putRevSlider(get_post_meta(get_the_id(), 'rvealias', true)); ?>
				<?php endwhile; ?>
					
			<?php else : ?>
				
			<?php endif; ?>
		<?php else : ?>
			<!-- page-banner-section 
			================================================== -->
			
			<?php if(is_front_page()) : ?>
			
				
			
			<?php else : ?>
		<section class="page-banner-section">
			<div class="container">
			
				<?php while(have_posts()) : the_post(); ?>
			
				<h2><?php the_title(); ?></h2>
				
				<?php endwhile; ?>
				
				<ul class="page-depth">
					<li><a href="<?php bloginfo('home'); ?>">Home</a></li>
					
					<?php while(have_posts()) : the_post(); ?>
					
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					
					<?php endwhile; ?>
					
				</ul>
			</div>
		</section>
			<?php endif; ?>
			
	
		<!-- End page-banner section -->
		<?php endif; ?>
		
		
		<!-- blog section 
			================================================== -->
	
		<?php while(have_posts()) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; ?>
						
				
	
		<!-- End blog section -->

		<?php get_footer(); ?>
		