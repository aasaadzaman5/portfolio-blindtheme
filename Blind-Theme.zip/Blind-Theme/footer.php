
<?php global $blind_theme; ?>
<!-- footer 
			================================================== -->
		<footer>
			<div class="up-footer">
				<div class="container">
					<div class="row">
					
						<div class="col-md-3">
							
							<?php dynamic_sidebar('footerwidget'); ?>
							
						
							
						</div>
						<div class="col-md-3">
						<?php dynamic_sidebar('footerwidget2'); ?>
							
						</div>
						<div class="col-md-3">
							
							<?php dynamic_sidebar('footerwidget3'); ?>
						
							
							
						</div>
						<div class="col-md-3">
						
						<?php dynamic_sidebar('footerwidget4'); ?>
						
							
						</div>
					</div>
				</div>
			</div>
			<p class="copyright">
				<?php echo $blind_theme['footertext']; ?>
			</p>
		</footer>
		<!-- End footer -->

	</div>
	<!-- End Container -->
	
	<?php wp_footer(); ?>

</body>
</html>