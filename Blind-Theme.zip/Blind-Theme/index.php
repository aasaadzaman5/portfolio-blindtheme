		
		<?php get_header(); ?>

		

		<!-- blog section 
			================================================== -->
		<section class="blog-section">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="blog-box">
						
							<?php if(have_posts()): ?>
							
						
								
							<?php while( have_posts()) :  the_post(); ?>

								<?php get_template_part('/template-parts/content', get_post_format()); ?>
							
							<?php endwhile; ?>
							
							<?php else : ?>
								<h2>You Didn't post yet...</h2>
							<?php endif; ?>
							
							<div class="pagination-list">
								<?php the_posts_pagination(array(
									'prev_text'				=>	__( 'PREV', 'blind'),
									'prev_text'				=>	__( 'PREV', 'blind'),
									'screen_reader_text'	=>	__( ' ', 'blind' ),
								)); ?>
							</div>
							
						</div>
						
					</div>
					<div class="col-md-3">
						<?php get_sidebar(); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- End blog section -->

		<?php get_footer(); ?>
		